public class Main {
    public static void main(String[] args) {
        SavingsAccount account = new SavingsAccount("John Doe", 2000, 5);

        account.deposit(1000);
        account.withdraw(700);
        account.addInterest();
        account.withdraw(3000); // should fail

        System.out.println("\nFinal Balance: " + account.getBalance());
        account.printTransactionHistory();
    }
}







