class SavingsAccount extends BankAccount {
    private double interestRate;

    public SavingsAccount(String accountHolder, double initialBalance, double interestRate) {
        super(accountHolder, initialBalance);
        this.interestRate = interestRate;
    }

    public void addInterest() {
        double interest = balance * interestRate / 100;
        deposit(interest);
        transactionHistory.add("Interest added: " + interest);
    }

    // Method overriding
    @Override
    public void withdraw(double amount) {
        if (balance - amount >= 500) { // maintain minimum balance
            super.withdraw(amount);
        } else {
            System.out.println("Cannot withdraw. Minimum balance of 500 required.");
        }
    }
}
